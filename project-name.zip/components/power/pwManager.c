#include "pwManager.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_system.h"
#include "esp_log.h"
#include "driver/gpio.h"
#include "sim7600.h"
#include "trackerData.h"
#include "eventHandler.h"

#define TAG "POWER"

static int ledState = 0;
static int fixState = 0;
static bool ignition_state = false;

static void power_init_gnss_led();
//static void io_manager_init();

void power_init() {
    ESP_LOGI(TAG, "Inicializando Power Manager...");
    power_on_module();
    power_press_key();
    power_init_gnss_led();
    //power_init_ignition();
    //io_manager_init();
}
// Encender el módulo SIM
void power_on_module() {
    gpio_reset_pin(POWER_SIM_PIN);
    ESP_LOGI(TAG, "Inicializando POWER SIM en PIN=%d", POWER_SIM_PIN);

    gpio_config_t io_conf = {};
    io_conf.pin_bit_mask = (1ULL << POWER_SIM_PIN);
    io_conf.mode = GPIO_MODE_OUTPUT;
    io_conf.pull_down_en = GPIO_PULLDOWN_DISABLE;
    io_conf.pull_up_en = GPIO_PULLUP_DISABLE;
    io_conf.intr_type = GPIO_INTR_DISABLE;

    gpio_config(&io_conf);
    gpio_set_level(POWER_SIM_PIN, 1);
}

// Apagar el módulo SIM
void power_off_module() {
    gpio_set_direction(POWER_SIM_PIN, GPIO_MODE_OUTPUT);
    gpio_set_level(POWER_SIM_PIN, 0);
}
int state_module() {
    int state = gpio_get_level(POWER_SIM_PIN);
    return state ? 1 : 0;
}
// Reiniciar el ESP32
void power_restart() {
    esp_restart();
}
// Activar la tecla de encendido del módulo SIM
void power_press_key() {
    gpio_reset_pin(POWER_KEY_PIN);
    ESP_LOGI(TAG, "Inicializando POWER KEY en PIN=%d", POWER_KEY_PIN);

    gpio_config_t io_conf = {};
    io_conf.pin_bit_mask = (1ULL << POWER_KEY_PIN);
    io_conf.mode = GPIO_MODE_OUTPUT;
    io_conf.pull_down_en = GPIO_PULLDOWN_DISABLE;
    io_conf.pull_up_en = GPIO_PULLUP_DISABLE;
    io_conf.intr_type = GPIO_INTR_DISABLE;

    gpio_config(&io_conf);
    gpio_set_level(POWER_KEY_PIN, 0);
    vTaskDelay(pdMS_TO_TICKS(1000));
    gpio_set_level(POWER_KEY_PIN, 1);
    vTaskDelay(pdMS_TO_TICKS(3000));
    //gpio_set_level(POWER_KEY_PIN, 0);
}
void led_task(void *arg) {
    TickType_t lastWakeTime = xTaskGetTickCount();
    
    while (1) {
        TickType_t interval = (fixState == 1) ? pdMS_TO_TICKS(150) : pdMS_TO_TICKS(1000); // Rápido (150ms) o lento (1000ms)   
        ledState = !ledState;  // Alterna el LED
        gpio_set_level(GNSS_LED_PIN, ledState);
        vTaskDelayUntil(&lastWakeTime, interval);
    }
}
// Configurar el LED GNSS
static void power_init_gnss_led() {
    gpio_reset_pin(GNSS_LED_PIN);
    ESP_LOGI(TAG, "Inicializando LED GNSS en PIN=%d", GNSS_LED_PIN);

    gpio_config_t io_conf = {};
    io_conf.pin_bit_mask = (1ULL << GNSS_LED_PIN);
    io_conf.mode = GPIO_MODE_OUTPUT;
    io_conf.pull_down_en = GPIO_PULLDOWN_DISABLE;
    io_conf.pull_up_en = GPIO_PULLUP_DISABLE;
    io_conf.intr_type = GPIO_INTR_DISABLE;

    gpio_config(&io_conf);
    gpio_set_level(GNSS_LED_PIN, 0); // Apagar inicialmente
    xTaskCreatePinnedToCore(led_task, "led_task", 2048, NULL, 2, NULL, tskNO_AFFINITY);
}
// Inicializar el pin de ignición
/*void power_init_ignition() {
    gpio_reset_pin(IGNITION_PIN);
    ESP_LOGI(TAG, "Inicializando IGNITION en PIN=%d", IGNITION_PIN);

    gpio_config_t io_conf = {};
    io_conf.pin_bit_mask = (1ULL << IGNITION_PIN);
    io_conf.mode = GPIO_MODE_INPUT;
    io_conf.pull_down_en = GPIO_PULLDOWN_DISABLE;
    io_conf.pull_up_en = GPIO_PULLUP_DISABLE; // Pull-up para detección de encendido
    io_conf.intr_type = GPIO_INTR_DISABLE;

    gpio_config(&io_conf);
}*/
static void io_monitor_task(void *arg) {
    bool last_ignition = gpio_get_level(IGNITION_PIN);
    bool last_input1 = gpio_get_level(INPUT1_PIN);
    bool last_input2 = gpio_get_level(INPUT2_PIN);

    ignition_state = last_ignition;
    ESP_LOGI(TAG, "Ignition inicial: %s", last_ignition ? "OFF" : "ON");
    ESP_LOGI(TAG, "Input1 inicial: %s", last_input1 ? "OFF" : "ON");
    ESP_LOGI(TAG, "Input2 inicial: %s", last_input2 ? "OFF" : "ON");

    esp_event_loop_handle_t loop = get_event_loop();

    if (loop) {
        esp_event_post_to(loop, SYSTEM_EVENTS, last_ignition ? IGNITION_OFF : IGNITION_ON, NULL, 0, portMAX_DELAY);
        esp_event_post_to(loop, SYSTEM_EVENTS, last_input1 ? INPUT1_OFF : INPUT1_ON, NULL, 0, portMAX_DELAY);
        esp_event_post_to(loop, SYSTEM_EVENTS, last_input2 ? INPUT2_OFF : INPUT2_ON, NULL, 0, portMAX_DELAY);
    }

    while (1) {
        bool current_ignition = gpio_get_level(IGNITION_PIN);
        bool current_input1 = gpio_get_level(INPUT1_PIN);
        bool current_input2 = gpio_get_level(INPUT2_PIN);

        if (current_ignition != last_ignition) {
            ignition_state = current_ignition;
            ESP_LOGI(TAG, "Ignition %s", current_ignition ? "OFF" : "ON");
            if (loop) {
                esp_event_post_to(loop, SYSTEM_EVENTS, current_ignition ? IGNITION_OFF : IGNITION_ON, NULL, 0, portMAX_DELAY);
            }
            last_ignition = current_ignition;
        }

        if (current_input1 != last_input1) {
            ESP_LOGI(TAG, "Input1 %s", current_input1 ? "OFF" : "ON");
            if (loop) {
                esp_event_post_to(loop, SYSTEM_EVENTS, current_input1 ? INPUT1_OFF : INPUT1_ON, NULL, 0, portMAX_DELAY);
            }
            last_input1 = current_input1;
        }

        if (current_input2 != last_input2) {
            ESP_LOGI(TAG, "Input2 %s", current_input2 ? "OFF" : "ON");
            if (loop) {
                esp_event_post_to(loop, SYSTEM_EVENTS, current_input2 ? INPUT2_OFF : INPUT2_ON, NULL, 0, portMAX_DELAY);
            }
            last_input2 = current_input2;
        }

        vTaskDelay(pdMS_TO_TICKS(50));
    }
}
void io_manager_init() {
     gpio_config_t io_conf = {
        .pin_bit_mask = (1ULL << IGNITION_PIN) | (1ULL << INPUT1_PIN) | (1ULL << INPUT2_PIN),
        .mode = GPIO_MODE_INPUT,
        .pull_up_en = GPIO_PULLUP_DISABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_DISABLE
    };
    gpio_config(&io_conf);

    xTaskCreate(io_monitor_task, "io_monitor_task", 4096, NULL, 5, NULL);
}
bool power_get_ignition_state() {
    //return gpio_get_level(IGNITION_PIN);
    return ignition_state;
}
void set_gnss_led_state(int state) {
    fixState = state; // Cambia la velocidad de parpadeo
}
void seco_init(void) {
    gpio_config_t io_conf = {
        .pin_bit_mask = (1ULL << OUTPUT1_PIN),
        .mode = GPIO_MODE_OUTPUT,
        .pull_up_en = GPIO_PULLUP_DISABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_DISABLE,
    };
    gpio_config(&io_conf);
}
void out2_init(void) {
    gpio_config_t io_conf = {
        .pin_bit_mask = (1ULL << OUTPUT2_PIN),
        .mode = GPIO_MODE_OUTPUT,
        .pull_up_en = GPIO_PULLUP_DISABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_DISABLE,
    };
    gpio_config(&io_conf);
}
void engineCutOn(void) {
    gpio_set_level(OUTPUT1_PIN, 1);
    vTaskDelay(pdMS_TO_TICKS(1000));
}

void engineCutOff(void) {
    gpio_set_level(OUTPUT1_PIN, 0);
    vTaskDelay(pdMS_TO_TICKS(1000));
}
/////// volver dinamicos la activación
void active_out2(void) {
    gpio_set_level(OUTPUT2_PIN, 1);
    vTaskDelay(pdMS_TO_TICKS(1000));
}
void desactive_out2(void) {
    gpio_set_level(OUTPUT2_PIN, 0);
    vTaskDelay(pdMS_TO_TICKS(1000));
}
/////////// eliminar las funciones de arriba //////////
int outputControl(int output , int state) {
    gpio_set_level(output, state);
    vTaskDelay(pdMS_TO_TICKS(1000));

    // Verifica si el estado del pin coincide con el solicitado
    int level = outputState(output);
    ESP_LOGI(TAG, "Level output:%d, state output:%d", level, state);
    return (level == state) ? 1 : 0;
}
int outputState(int output) {
  
    int level = gpio_get_level(output);
    ESP_LOGI(TAG, "OUT STATE:%d", level);
    return level ? 1 : 0;
}

void init_inputs(void) {
    // Configurar ambos pines como entrada
    gpio_config_t io_conf = {
        .pin_bit_mask = (1ULL << INPUT1_PIN) | (1ULL << INPUT2_PIN),
        .mode = GPIO_MODE_INPUT,
        .pull_up_en = GPIO_PULLUP_DISABLE,  // ya tienes resistencias pull-up externas
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_DISABLE
    };
    gpio_config(&io_conf);
}

